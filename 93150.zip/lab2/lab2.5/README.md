#### Dadatset from: `https://github.com/huynhsamha/quick-mongo-atlas-datasets`

##### using only `movies.bson`. The file is not in the folder because it was too large for e-learning

	$mongorestore --db rest --dir movies.bson

